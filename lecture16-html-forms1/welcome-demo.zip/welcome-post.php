<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title>Welcome Demo</title>
</head>
<body>

Welcome <?php echo $_POST["name"]; ?>

</body>
</html>